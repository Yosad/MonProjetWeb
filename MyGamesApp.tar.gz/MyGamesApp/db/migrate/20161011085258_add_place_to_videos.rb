class AddPlaceToVideos < ActiveRecord::Migration
  def change
    add_column :videos, :place, :integer
  end
end
