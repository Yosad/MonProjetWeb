class VideosController < ApplicationController
  def show
	@video = Video.joins(:Game)
		.where(
		    'games.slug' => params[:slug_game],
		    'slug' => params[:slug_video]
		).first
  end
end
