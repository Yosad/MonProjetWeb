class RemoveOrdreFromVideos < ActiveRecord::Migration
  def change
    remove_column :videos, :ordre, :integer
  end
end
