require 'test_helper'

class VideosControllerTest < ActionController::TestCase
  test "should get show" do
    get :show
    assert_response :success
  end

end
