class Game < ActiveRecord::Base
   has_many :videos

end
