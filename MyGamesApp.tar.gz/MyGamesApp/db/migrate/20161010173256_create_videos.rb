class CreateVideos < ActiveRecord::Migration
  def change
    create_table :videos do |t|
      t.string :title
      t.text :description
      t.integer :ordre
      t.string :video_link
      t.belongs_to :Game, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
